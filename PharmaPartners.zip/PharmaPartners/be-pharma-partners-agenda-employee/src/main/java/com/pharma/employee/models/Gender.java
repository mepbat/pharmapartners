package com.pharma.employee.models;

public enum Gender {
    Male,
    Female,
    Other
}
