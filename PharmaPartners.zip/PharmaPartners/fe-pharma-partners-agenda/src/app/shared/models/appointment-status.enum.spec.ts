import { AppointmentStatus.Enum.Ts } from './appointment-status.enum.ts';

describe('AppointmentStatus.Enum.Ts', () => {
  it('should create an instance', () => {
    expect(new AppointmentStatus.Enum.Ts()).toBeTruthy();
  });
});
