export class Employee {
  id: bigint;
  firstName: string;
  lastName: string;
  middleName: string;
  gender: string;
  dateOfbirth: string;
}
