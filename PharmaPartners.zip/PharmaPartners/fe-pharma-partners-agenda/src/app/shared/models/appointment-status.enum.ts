export enum AppointmentStatus {
  ABSENT,
  REGISTERED,
  DONE
}
