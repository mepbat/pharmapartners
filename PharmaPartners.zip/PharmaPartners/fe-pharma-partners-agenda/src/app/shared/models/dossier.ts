export class Dossier {
  id: number;
  information: string;
}
