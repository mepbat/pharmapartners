export class Location {
  id: number;
  zipCode: string;
  street: string;
  houseNumber: string;
  city: string;
  country: string;
}
