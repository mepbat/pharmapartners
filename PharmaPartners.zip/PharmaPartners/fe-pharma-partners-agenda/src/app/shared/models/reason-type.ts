export class ReasonType {
  id: number;
  name: string;
}
