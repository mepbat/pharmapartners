import { AppointmentType } from './appointment-type';

describe('AppointmentType', () => {
  it('should create an instance', () => {
    expect(new AppointmentType()).toBeTruthy();
  });
});
