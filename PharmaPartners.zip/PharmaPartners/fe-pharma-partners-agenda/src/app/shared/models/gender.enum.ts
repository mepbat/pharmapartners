export enum Gender {
  Man,
  Vrouw,
  Anders
}
