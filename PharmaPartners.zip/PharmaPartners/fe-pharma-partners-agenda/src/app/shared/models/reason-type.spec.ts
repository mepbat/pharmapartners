import { ReasonType } from './reason-type';

describe('ReasonType', () => {
  it('should create an instance', () => {
    expect(new ReasonType()).toBeTruthy();
  });
});
