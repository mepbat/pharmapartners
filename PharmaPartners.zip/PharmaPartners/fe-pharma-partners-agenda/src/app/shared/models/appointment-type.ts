export class AppointmentType {
  id: number;
  name: string;
}
