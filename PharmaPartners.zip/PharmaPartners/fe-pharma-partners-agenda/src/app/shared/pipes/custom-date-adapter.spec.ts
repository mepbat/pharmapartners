import { CustomDateAdapter } from './custom-date-adapter';

describe('CustomDateAdapter', () => {
  it('should create an instance', () => {
    expect(new CustomDateAdapter()).toBeTruthy();
  });
});
