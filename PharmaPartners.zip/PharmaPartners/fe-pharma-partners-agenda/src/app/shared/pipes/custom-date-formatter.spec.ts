import { CustomDateFormatter } from './custom-date-formatter';

describe('CustomDateFormatter', () => {
  it('should create an instance', () => {
    expect(new CustomDateFormatter()).toBeTruthy();
  });
});
