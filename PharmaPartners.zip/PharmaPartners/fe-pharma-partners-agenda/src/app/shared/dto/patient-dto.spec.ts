import { PatientDto } from './patient-dto';

describe('PatientDto', () => {
  it('should create an instance', () => {
    expect(new PatientDto()).toBeTruthy();
  });
});
