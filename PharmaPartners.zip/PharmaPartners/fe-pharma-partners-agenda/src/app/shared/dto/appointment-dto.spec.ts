import { AppointmentDto } from './appointment-dto';

describe('AppointmentDto', () => {
  it('should create an instance', () => {
    expect(new AppointmentDto()).toBeTruthy();
  });
});
