import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-search',
  templateUrl: './appointment-search.component.html',
  styleUrls: ['./appointment-search.component.css']
})
export class AppointmentSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
