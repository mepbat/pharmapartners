package com.pharma.appointments.models;

public enum AppointmentStatus {
    ABSENT,
    REGISTERED,
    DONE
}
