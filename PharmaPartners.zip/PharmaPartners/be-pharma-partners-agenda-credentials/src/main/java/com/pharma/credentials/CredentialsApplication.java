package com.pharma.credentials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CredentialsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CredentialsApplication.class, args);
	}

}
