package com.pharma.patientrecords;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
//class PatientRecordsApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
