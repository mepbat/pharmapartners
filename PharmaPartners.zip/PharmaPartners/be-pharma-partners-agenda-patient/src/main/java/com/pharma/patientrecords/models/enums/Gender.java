package com.pharma.patientrecords.models.enums;

public enum Gender {
    Man,
    Vrouw,
    Anders
}
