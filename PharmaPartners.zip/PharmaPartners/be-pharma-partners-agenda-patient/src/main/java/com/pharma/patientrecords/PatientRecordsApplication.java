package com.pharma.patientrecords;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientRecordsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientRecordsApplication.class, args);
	}

}
